<html xmlns="http://www.w3.org/1999/xhtml">
    <head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
        
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>ACCESO DENEGADO</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <link rel="stylesheet" href="CSS/index.css" type="text/css">
        <link rel="stylesheet" href="/CSS/style.css">
    
    <body>
        <main class="container p-4">
            <div id="error" class="jumbotron p-4">
                <h1 class="display-4" style="color:green;""> ACCESO DENEGADO</h1>
            </div>
        </main>
    </body>
</html>
